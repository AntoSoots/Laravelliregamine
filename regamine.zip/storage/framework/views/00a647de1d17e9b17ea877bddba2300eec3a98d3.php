<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <h1>Kasutajad</h1>
            <table class="table table-responsive">
                <thead>
                    <tr>
                        <th scope="col">Ettevõte</th>
                        <th scope="col">Ettevõtte nimi</th>
                        <th scope="col">Ettevõtte registrikood</th>
                        <th scope="col">Nimi</th>
                        <th scope="col">Vanus</th>
                        <th scope="col">E-mail</th>
                        <th scope="col">Muuda</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($user->company); ?></td>
                            <td><?php echo e($user->companyName); ?></td>
                            <td><?php echo e($user->companyCode); ?></td>
                            <td><?php echo e($user->name); ?></td>
                            <td><?php echo e($user->age); ?></td>
                            <td><?php echo e($user->email); ?></td>
                            <td><a href = 'edit/<?php echo e($user->id); ?>'>Muuda</a></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\soots\Desktop\regamine\resources\views/home.blade.php ENDPATH**/ ?>