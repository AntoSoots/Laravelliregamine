<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="header"><h1>Kasutajad </h1></div>

        <div class="row">
            <h5 class="ml-3 pt-1">Filtrid:</h5>
            <a href="/home" class="h5 pt-1 px-2">Kõik</a> <h5 class="pt-1">|</h5>
            <a href="/home?companies" class="h5 pt-1 pl-2">Ettevõtted</a> <h5 class="pt-1">/</h5>
            <a href="/home?citizen" class="h5 pt-1">Eraisikud</a>
            <form method="GET" class="ml-2">
                    <input id="companyName" class="filter form-control form-control-sm" type="text" name="companyName" onclick="/home?companyName" placeholder="Ettevõtte nimi">
            </form>
            <form method="GET" class="ml-2">
                    <input id="companyCode" class="filter form-control form-control-sm" type="text" name="companyCode" onclick="/home?companyCode" placeholder="Ettevõtte registrikood">
            </form>
            <form method="GET" class="ml-2">
                    <input id="name" class="filter form-control form-control-sm" type="text" name="name" onclick="/home?name" placeholder="Nimi">
            </form>
            <form method="GET" class="ml-2">
                    <input id="age" class="filter form-control form-control-sm" type="text" name="age" onclick="/home?age" placeholder="Vanus" maxlength="2">
            </form>
            <form method="GET" class="ml-2">
                    <input id="email" class="filter form-control form-control-sm" type="text" name="email" onclick="/home?email" placeholder="Email">
            </form>
        </div>
            <hr>
        <div class="container">
            <table id="myTable" class="table table-responsive table-striped">
                <thead>
                    <tr>
                        <th>Ettevõte</th>
                        <th>Ettevõtte nimi</th>
                        <th>Ettevõtte registrikood</th>
                        <th>Nimi</th>
                        <th>Vanus</th>
                        <th>E-mail</th>
                        <th>Muuda</th>
                    </tr>
                </thead>
                <tbody>

                <?php if(count ($users) > 0): ?>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php if($user->company > 0): ?> Jah <?php else: ?> Ei <?php endif; ?></td>
                            <td><?php echo e($user->companyName); ?></td>
                            <td><?php echo e($user->companyCode); ?></td>
                            <td><?php echo e($user->name); ?></td>
                            <td><?php echo e($user->age); ?></td>
                            <td><?php echo e($user->email); ?></td>
                            <td><a href = 'edit/<?php echo e($user->id); ?>'>Muuda</a></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?> <tr>
                    <td colspan="7">Tabeli sisu puudub!!!</td>
                </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <div class="container">
            <?php echo e($users->links()); ?>

        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\soots\Desktop\Uus kaust\regamine\resources\views/home.blade.php ENDPATH**/ ?>